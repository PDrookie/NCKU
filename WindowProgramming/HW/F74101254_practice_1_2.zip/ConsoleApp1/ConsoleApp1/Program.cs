﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int cash = 0, counting;
            string convert;
            string Read;
            double percent;
            int ExpenditureProject;
            int Expenditure = 0;
            int method;
            List<string> projects = new List<string>();
            int[] expand = new int[5] { 0, 0, 0, 0, 0 };
            for (; ; )
            {
                Console.WriteLine("(1)輸入收入 (2)輸入支出 (3)新增項目 (4)刪除項目 (5)計算比例 (6)查詢支出 (7)剩餘金額 (8)退出程式");
                Console.Write("輸入數字選擇功能: ");
                method = Convert.ToInt32(Console.ReadLine());

                switch (method)
                {
                    case 1:
                        Console.Write("輸入金額:");        
                        convert = Console.ReadLine();
                        bool isNumeric = int.TryParse(convert, out counting);
                        if (isNumeric == true)
                        {
                            if (counting >= 0)
                                cash += counting;
                            else if(counting <= 0)
                                Console.WriteLine("收入不可為負數");
                        }
                        else
                            Console.WriteLine("請輸入數字");
                            break;
                    case 2:
                        Expenditure = 0;
                        if (projects.Count == 0)
                            Console.WriteLine("請新增支出項目");
                        else
                        {
                            for (int i = 0; i < projects.Count; i++)
                            {
                                int k = i + 1;
                                Console.Write("(" + k + ")" + projects[i] + " ");

                            }
                            Console.WriteLine();
                            Console.Write("輸入數字選擇支出項目: ");
                            ExpenditureProject = Convert.ToInt32(Console.ReadLine());
                            if (ExpenditureProject > projects.Count || ExpenditureProject > 5)
                            {
                                Console.WriteLine("此數字不在範圍中");
                            }
                            else
                            {
                                Console.Write("輸入支出金額:");
                                counting = Convert.ToInt32(Console.ReadLine());
                                if (cash < counting)
                                {
                                    Console.WriteLine("存款不足");
                                }
                                else
                                {
                                    switch (ExpenditureProject)
                                    {
                                        case 1:
                                            expand[0] += counting;
                                            break;
                                        case 2:
                                            expand[1] += counting;
                                            break;
                                        case 3:
                                            expand[2] += counting;
                                            break;
                                        case 4:
                                            expand[3] += counting;
                                            break;
                                        case 5:
                                            expand[4] += counting;
                                            break;
                                    }
                                    for (int i = 0; i < 5; i++)
                                    {
                                        Expenditure += expand[i];
                                    }
                                }
                            }
                        }
                        break;
                    case 3:                     
                        Console.Write("輸入項目名稱: ");
                        Read = Console.ReadLine();
                        if (projects.Contains(Read)) 
                        {
                            Console.WriteLine("支出項目已存在");
                        }
                        else if(projects.Count > 5)
                        {
                            Console.WriteLine("已無法再新增支出項目");
                        }
                        else
                        projects.Add(Read);
                        break;
                    case 4:
                        Console.Write("輸入項目名稱: ");
                        Read = Console.ReadLine();                        
                        if (projects.Contains(Read))
                        {
                            int j = 0;
                            if (Read == projects[0])
                            {
                                Console.WriteLine(Expenditure);
                                Expenditure -= expand[0];
                                Console.WriteLine(Expenditure + " After");
                                for (int i = 0; i < 4; i++)
                                {
                                    expand[i] = expand[i + 1];
                                }
                            }
                            else if (Read == projects[1])
                            {
                                Console.WriteLine(Expenditure);
                                Expenditure -= expand[1];
                                Console.WriteLine(Expenditure + " After");
                                for (int i = 1; i < 4; i++)
                                {
                                    expand[i] = expand[i + 1];
                                }
                            }
                            else if (Read == projects[2])
                            {
                                Console.WriteLine(Expenditure);
                                Expenditure -= expand[2];
                                Console.WriteLine(Expenditure + " After");
                                for (int i = 2; i < 4; i++)
                                {
                                    expand[i] = expand[i + 1];
                                }
                            }
                            else if (Read == projects[3])
                            {
                                Console.WriteLine(Expenditure);
                                Expenditure -= expand[3];
                                Console.WriteLine(Expenditure + " After");
                                for (int i = 3; i < 4; i++)
                                {
                                    expand[i] = expand[i + 1];
                                }
                            }
                            else if (Read == projects[4])
                            {
                                Console.WriteLine(Expenditure);
                                Expenditure -= expand[4];
                                Console.WriteLine(Expenditure + " After");
                                expand[4] = 0;
                            }
                                                      
                            projects.Remove(Read);
                        }
                        else
                            Console.WriteLine("此項目不存在");
                        if(projects.Count == 0)
                        {
                            Console.WriteLine("已無法再支出項目");
                        }
                        break;
                    case 5:
                        for(int i = 0; i < projects.Count; i++)
                        {
                            //Console.WriteLine(expand[i] + " " + Expenditure);
                            int k = i + 1;
                            percent = (double)expand[i] / Expenditure * 100;
                            Console.WriteLine("(" + k + ")" + projects[i] + ": " + percent + "%");
                        }
                        break;
                    case 6:
                        Console.WriteLine("目前總支出: " + Expenditure);
                        Console.Write("輸入要查詢項目: ");
                        string search = Console.ReadLine();
                        if (projects.Contains(search))
                        {
                            if(search == projects[0]){
                                Console.WriteLine(projects[0] + ": " + expand[0]);
                            }
                            else if (search == projects[1])
                            {
                                Console.WriteLine(projects[1] + ": " + expand[1]);
                            }
                            else if (search == projects[2])
                            {
                                Console.WriteLine(projects[2] + ": " + expand[2]);
                            }
                            else if (search == projects[3])
                            {
                                Console.WriteLine(projects[3] + ": " + expand[3]);
                            }
                            else if (search == projects[4])
                            {
                                Console.WriteLine(projects[4] + ": " + expand[4]);
                            }
                        }
                        else
                            Console.WriteLine("此項目不存在");
                        break;
                    case 7:
                        Console.WriteLine("剩餘金額為:{0} ", cash - Expenditure);
                        break;
                }
                if (method == 8)
                    break;
                else
                    Console.WriteLine();

            }
            Console.ReadLine();

        }
    }
}
