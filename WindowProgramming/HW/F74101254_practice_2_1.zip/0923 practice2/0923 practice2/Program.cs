﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0923_practice2
{
    class Program
    {
        static void Main(string[] args)
        {
            int COLS = 4, ROWS = 0;
            int method, weekday, start, end;
            List<string> Monday = new List<string>();
            List<string> Tuesday = new List<string>();
            List<string> Wednesday = new List<string>();
            List<string> Thursday = new List<string>();
            List<string> Friday = new List<string>();
            List<string> Saturday = new List<string>();
            List<string> Sunday = new List<string>();
            for(int i = 0; i <= 8; i++)
            {
                Monday.Add("      ");
                Tuesday.Add("      ");
                Wednesday.Add("      ");
                Thursday.Add("      ");
                Friday.Add("      ");
                Saturday.Add("      ");
                Sunday.Add("      ");
            }
            string[,] LessonDetail = new string[4, 16];
            string lesson;
            for (; ; )
            {
                   
                Console.WriteLine("(1)新增課程 (2)刪除課程 (3)列印課表 (4)計算學分 (5)離開程式");
                Console.Write("輸入數字選擇功能: ");
                method = Convert.ToInt32(Console.ReadLine());                
                switch (method)
                {
                    case 1:
                        int check = 0;
                        Console.WriteLine("請輸入要加入的課程，格式為<課程代號 星期 開始節 結束節>");
                        lesson = Console.ReadLine();
                        string[] convert = lesson.Split(' ');
                        weekday = Convert.ToInt32(convert[1]);
                        start = Convert.ToInt32(convert[2]);
                        end = Convert.ToInt32(convert[3]);
                        switch (weekday)
                        {
                            case 1:
                                if (Monday.Contains(convert[0]))
                                {
                                    Console.WriteLine("課程重複！");
                                    check++;
                                }
                                else
                                {
                                    for (int j = start; j <= end; j++)
                                    {
                                        if (Monday[j] != "      ")
                                        {
                                            Console.WriteLine("課程衝堂！");
                                            check++;
                                            break;
                                        }
                                    }
                                    if (check == 0)
                                    {
                                        for (int j = start; j <= end; j++)
                                        {
                                            Monday[j] = convert[0];
                                        }
                                        Console.WriteLine("成功加入課程！");
                                    }
                                }                                                             
                            break;
                            case 2:
                                if (Tuesday.Contains(convert[0]))
                                {
                                    Console.WriteLine("課程重複！");
                                    check++;
                                }
                                else {
                                    for (int j = start; j <= end; j++)
                                    {

                                        if (Tuesday[j] != "      ")
                                        {
                                            Console.WriteLine("課程衝堂！");
                                            check++;
                                            break;
                                        }
                                    }
                                    if (check == 0)
                                    {
                                        for (int j = start; j <= end; j++)
                                        {
                                            Tuesday[j] = convert[0];
                                        }
                                        Console.WriteLine("成功加入課程！");
                                    }
                                }                                
                                break;
                            case 3:
                                if (Wednesday.Contains(convert[0]))
                                {
                                    Console.WriteLine("課程重複！");
                                    check++;
                                }
                                else
                                {
                                    for (int j = start; j <= end; j++)
                                    {

                                        if (Wednesday[j] != "      ")
                                        {
                                            Console.WriteLine("課程衝堂！");
                                            check++;
                                            break;
                                        }
                                    }
                                    if (check == 0)
                                    {
                                        for (int j = start; j <= end; j++)
                                        {
                                            Wednesday[j] = convert[0];
                                        }
                                        Console.WriteLine("成功加入課程！");
                                    }
                                }                                
                                break;
                            case 4:
                                if (Thursday.Contains(convert[0]))
                                {
                                    Console.WriteLine("課程重複！");
                                    check++;
                                }
                                else
                                {
                                    for (int j = start; j <= end; j++)
                                    {
                                        if (Thursday[j] != "      ")
                                        {
                                            Console.WriteLine("課程衝堂！");
                                            check++;
                                            break;
                                        }
                                    }
                                    if (check == 0)
                                    {
                                        for (int j = start; j <= end; j++)
                                        {
                                            Thursday[j] = convert[0];
                                        }
                                        Console.WriteLine("成功加入課程！");
                                    }
                                }                                
                                break;
                            case 5:
                                if (Friday.Contains(convert[0]))
                                {
                                    Console.WriteLine("課程重複！");
                                    check++;
                                }
                                else
                                {
                                    for (int j = start; j <= end; j++)
                                    {
                                        if (Friday[j] != "      ")
                                        {
                                            Console.WriteLine("課程衝堂！");
                                            check++;
                                            break;
                                        }
                                    }
                                    if (check == 0)
                                    {
                                        for (int j = start; j <= end; j++)
                                        {
                                            Friday[j] = convert[0];
                                        }
                                        Console.WriteLine("成功加入課程！");
                                    }
                                }                                
                                break;
                            case 6:
                                if (Saturday.Contains(convert[0]))
                                {
                                    Console.WriteLine("課程重複！");
                                    check++;
                                }
                                else
                                {
                                    for (int j = start; j <= end; j++)
                                    {
                                        if (Saturday[j] != "      ")
                                        {
                                            Console.WriteLine("課程衝堂！");
                                            check++;
                                            break;
                                        }
                                    }
                                    if (check == 0)
                                    {
                                        for (int j = start; j <= end; j++)
                                        {
                                            Saturday[j] = convert[0];
                                        }
                                        Console.WriteLine("成功加入課程！");
                                    }
                                }                               
                                break;
                            case 7:
                                if (Sunday.Contains(convert[0]))
                                {
                                    Console.WriteLine("課程重複！");
                                    check++;
                                }
                                else
                                {
                                    for (int j = start; j <= end; j++)
                                    {
                                        if (Sunday[j] != "      ")
                                        {
                                            Console.WriteLine("課程衝堂！");
                                            check++;
                                            break;
                                        }
                                    }
                                    if (check == 0)
                                    {
                                        for (int j = start; j <= end; j++)
                                        {
                                            Sunday[j] = convert[0];
                                        }
                                        Console.WriteLine("成功加入課程！");
                                    }
                                }                                
                                break;
                        }
                        break;
                    case 2:
                        string delete;
                        Console.Write("請輸入要刪除的課程代號:");
                        delete = Console.ReadLine();
                        if (Monday.Contains(delete))
                        {
                            for(int k = 1;k <= 8; k++)
                            {
                                if(Monday[k] == delete)
                                {
                                    Monday[k] = "      ";
                                }                                
                            }
                            Console.WriteLine("成功刪除課程：" + delete);
                        }
                        else if (Tuesday.Contains(delete))
                        {
                            for (int k = 1; k <= 8; k++)
                            {
                                if(Tuesday[k] == delete)
                                {
                                    Tuesday[k] = "      ";
                                }
                            }
                            Console.WriteLine("成功刪除課程：" + delete);
                        }
                        else if (Wednesday.Contains(delete))
                        {
                            for (int k = 1; k <= 8; k++)
                            {
                                if (Wednesday[k] == delete)
                                {
                                    Wednesday[k] = "      ";
                                }
                            }
                            Console.WriteLine("成功刪除課程：" + delete);
                        }
                        else if (Thursday.Contains(delete))
                        {
                            for (int k = 1; k <= 8; k++)
                            {
                                if (Thursday[k] == delete)
                                {
                                    Thursday[k] = "      ";
                                }
                            }
                            Console.WriteLine("成功刪除課程：" + delete);
                        }
                        else if (Friday.Contains(delete))
                        {
                            for (int k = 1; k <= 8; k++)
                            {
                                if (Friday[k] == delete)
                                {
                                    Friday[k] = "      ";
                                }
                            }
                            Console.WriteLine("成功刪除課程：" + delete);
                        }
                        else if (Saturday.Contains(delete))
                        {
                            for (int k = 1; k <= 8; k++)
                            {
                                if (Saturday[k] == delete)
                                {
                                    Saturday[k] = "      ";
                                }
                            }
                            Console.WriteLine("成功刪除課程：" + delete);
                        }
                        else if (Sunday.Contains(delete))
                        {
                            for (int k = 1; k <= 8; k++)
                            {
                                if (Sunday[k] == delete)
                                {
                                    Sunday[k] = "      ";
                                }
                            }
                            Console.WriteLine("成功刪除課程：" + delete);
                        }
                        else
                        {
                            Console.WriteLine("課程" + delete + "不在課表中");
                        }
                        break;
                    case 3:
                        Console.WriteLine("      Sun   Mon   Tue   Wed   Thu   Fri   Sat");
                        for(int j  = 1; j <= 8; j++)
                        {
                            Console.WriteLine(j + "     " + Sunday[j] + Monday[j] + Tuesday[j] + Wednesday[j] + Thursday[j] + Friday[j] + Saturday[j]);
                        }
                        
                        
                        break;
                    case 4:
                        int credit = 0;
                        for(int j  = 0; j <= 8; j++)
                        {
                            if(Monday[j] != "      " || Tuesday[j] != "      " || Wednesday[j] != "      " || Thursday[j] != "      " || Friday[j] != "      " || Saturday[j] != "      " || Sunday[j] != "      ")
                            {
                                credit++;
                            }
                        }
                        Console.WriteLine(credit);
                        break;
                }
                if (method == 5)
                    break;
                else
                    Console.WriteLine();

            }
            Console.ReadLine();

        }

    }
}
