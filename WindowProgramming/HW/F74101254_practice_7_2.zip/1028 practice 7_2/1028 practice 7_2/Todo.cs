﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace _1028_practice_7_2
{
    class Todo
    {
        public string output, check, task;

        public Todo(string _output, string _check, string _task)
        {
            output = _output;
            check = _check;
            task = _task;
        }
    }
}