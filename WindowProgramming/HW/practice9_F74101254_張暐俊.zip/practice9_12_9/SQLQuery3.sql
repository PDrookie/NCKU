﻿DELETE FROM 電話_員工編號 WHERE 員工編號 = 'F71234567'
SELECT * FROM 員工編號_姓名_電子信箱 WHERE 姓名 = 'Lewis'
SELECT * FROM 電話_員工編號 WHERE 員工編號 = 'F71234567'
SELECT * FROM 員工編號_薪水 WHERE 員工編號 = 'F71234567'